The only file you need to create a web browser based graphical
user interface for your software is the file webgui.c in the parent 
directory. Compile and link this file with your software and call 
its public functions listed in the documentation file WEBGUI.pdf.
The files in this directory are only needed if you wish 
to modify webgui.c and/or modify the documentation pdf.